#testpackage

This package calculates censored ROC given times and events